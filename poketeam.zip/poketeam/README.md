# PokéTeam

CRUD de um time Pokémon com **Node.js + Express + SQLite** (backend) e **HTML, CSS e JavaScript puro** (frontend),
consumindo a **PokéAPI** (https://pokeapi.co, pública e sem chave).

> **Equipe:** Agatha e Vito — **Disciplina:** Programação para Internet 2026 — Prof. Fernando

## Como a API externa é usada

1. O usuário busca um Pokémon por nome ou número → `GET /api/pokedex/:nome`.
2. O backend chama a PokéAPI (`services/pokeApiService.js`) e devolve espécie, tipos, imagem, HP, ataque e defesa.
3. Ao capturar (`POST /api/pokemons`), o backend consulta a PokéAPI de novo e grava os dados oficiais no SQLite,
   junto com apelido, nível e anotações do usuário. Assim o navegador nunca inventa dados da espécie.
4. Erros tratados: Pokémon inexistente (404), PokéAPI fora do ar ou lenta (502, timeout de 8 s).

## Estrutura

```
backend/
  server.js
  src/app.js                        # Express, CORS, JSON, log, frontend estático, erros
  src/routes/pokemonRoutes.js       # método + caminho
  src/controllers/pokemonController.js  # status HTTP; orquestra model e API
  src/models/pokemonModel.js        # validação e SQL
  src/services/pokeApiService.js    # integração com a PokéAPI
  src/config/database.js            # SQLite e criação da tabela
frontend/
  index.html  css/styles.css  js/api.js (fetch)  js/app.js (DOM e eventos)
```

## Endpoints

| Método | Rota | Corpo | Sucesso | Erros |
|---|---|---|---|---|
| GET | `/api/pokedex/:nome` | — | 200 + dados da PokéAPI | 404, 502 |
| GET | `/api/pokemons?busca=` | — | 200 + lista | — |
| GET | `/api/pokemons/:id` | — | 200 + Pokémon | 400, 404 |
| POST | `/api/pokemons` | `{ especie, apelido, nivel, notas }` | 201 + Pokémon | 400, 404, 502 |
| PUT | `/api/pokemons/:id` | `{ apelido, nivel, notas }` | 200 + Pokémon | 400, 404 |
| DELETE | `/api/pokemons/:id` | — | 204 | 400, 404 |

Erros: `{ "erro": "mensagem" }`. **Regras:** apelido até 30 caracteres, nível inteiro de 1 a 100, notas até 300.
A espécie não muda depois de capturada (o PUT altera só apelido, nível e notas).

## Como rodar

Requisito: Node.js 18+ (usa o `fetch` nativo) e internet para acessar a PokéAPI.

```bash
cd backend
npm install
npm start
```

Abra http://localhost:3000.

## Subir para o repositório

```bash
git init && git add . && git commit -m "PokéTeam - CRUD com PokéAPI"
git branch -M main
git remote add origin <URL-DO-REPOSITORIO>
git push -u origin main
```
