// Única camada que usa fetch (fala só com o nosso backend; ele é quem chama a PokéAPI).
const API_URL = location.port === "3000" ? "/api" : "http://localhost:3000/api";

async function requisitar(url, opcoes = {}) {
  const resposta = await fetch(url, { headers: { "Content-Type": "application/json" }, ...opcoes });
  if (resposta.status === 204) return null;
  const corpo = await resposta.json();
  if (!resposta.ok) throw new Error(corpo.erro || "Erro na requisição.");
  return corpo;
}

const api = {
  pokedex: (nome) => requisitar(`${API_URL}/pokedex/${encodeURIComponent(nome)}`),
  listar: (busca = "") => requisitar(`${API_URL}/pokemons?busca=${encodeURIComponent(busca)}`),
  buscar: (id) => requisitar(`${API_URL}/pokemons/${id}`),
  criar: (dados) => requisitar(`${API_URL}/pokemons`, { method: "POST", body: JSON.stringify(dados) }),
  atualizar: (id, dados) => requisitar(`${API_URL}/pokemons/${id}`, { method: "PUT", body: JSON.stringify(dados) }),
  excluir: (id) => requisitar(`${API_URL}/pokemons/${id}`, { method: "DELETE" }),
};
