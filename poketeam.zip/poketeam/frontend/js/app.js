// DOM e eventos. Não conhece URLs.
const $ = (id) => document.getElementById(id);

function mostrarMensagem(texto, tipo = "ok") {
  $("mensagem").textContent = texto;
  $("mensagem").className = tipo;
}

function el(tag, texto, classe) {
  const e = document.createElement(tag);
  if (texto !== undefined) e.textContent = texto; // textContent evita injeção de HTML
  if (classe) e.className = classe;
  return e;
}

function celula(...filhos) {
  const td = document.createElement("td");
  td.append(...filhos);
  return td;
}

function tipos(lista) {
  const span = el("span");
  lista.split(",").filter(Boolean).forEach((t) => span.append(el("span", t, "tipo")));
  return span;
}

function imagem(src, alt) {
  const i = document.createElement("img");
  i.src = src;
  i.alt = alt;
  return i;
}

function botao(texto, rotulo, classe, aoClicar) {
  const b = el("button", texto, classe);
  b.type = "button";
  b.setAttribute("aria-label", rotulo);
  b.addEventListener("click", aoClicar);
  return b;
}

function mostrarPrevia(p) {
  const div = $("previa");
  div.replaceChildren(
    imagem(p.imagem, `Imagem de ${p.especie}`),
    (() => {
      const info = document.createElement("div");
      info.append(el("h3", `#${p.especie_id} ${p.especie}`, "nome"), tipos(p.tipos),
        el("p", `HP ${p.hp} · Ataque ${p.ataque} · Defesa ${p.defesa}`));
      return info;
    })()
  );
  div.hidden = false;
}

async function carregar() {
  try {
    const lista = await api.listar($("busca").value);
    const tbody = $("tabela");
    tbody.replaceChildren();
    if (!lista.length) {
      const td = celula("Nenhum Pokémon no time.");
      td.colSpan = 6;
      const tr = document.createElement("tr");
      tr.append(td);
      tbody.append(tr);
      return;
    }
    for (const p of lista) {
      const nome = el("span", p.apelido ? `${p.apelido} (${p.especie})` : p.especie, "nome");
      const tr = document.createElement("tr");
      tr.append(
        celula(imagem(p.imagem, `Imagem de ${p.especie}`)),
        celula(nome),
        celula(tipos(p.tipos)),
        celula(String(p.nivel)),
        celula(`${p.hp}/${p.ataque}/${p.defesa}`),
        (() => {
          const td = celula(
            botao("Editar", `Editar ${p.apelido || p.especie}`, "neutro", () => iniciarEdicao(p.id)),
            " ",
            botao("Soltar", `Soltar ${p.apelido || p.especie}`, "perigo", () => soltar(p))
          );
          td.className = "acoes-celula";
          return td;
        })()
      );
      tbody.append(tr);
    }
  } catch (e) {
    mostrarMensagem(e.message, "erro");
  }
}

function limparFormulario() {
  $("form").reset();
  $("id").value = "";
  $("especie-escolhida").value = "";
  $("escolhido").textContent = "Busque um Pokémon acima para capturar.";
  $("titulo-form").textContent = "2. Capturar Pokémon";
  $("btn-salvar").textContent = "Capturar";
  $("btn-cancelar").hidden = true;
  $("previa").hidden = true;
}

async function iniciarEdicao(id) {
  try {
    const p = await api.buscar(id);
    $("id").value = p.id;
    $("especie-escolhida").value = p.especie;
    $("escolhido").textContent = `Editando ${p.especie} (a espécie não muda).`;
    $("apelido").value = p.apelido;
    $("nivel").value = p.nivel;
    $("notas").value = p.notas;
    $("titulo-form").textContent = `Editar Pokémon #${p.id}`;
    $("btn-salvar").textContent = "Salvar alterações";
    $("btn-cancelar").hidden = false;
    $("apelido").focus();
  } catch (e) {
    mostrarMensagem(e.message, "erro");
  }
}

async function soltar(p) {
  if (!confirm(`Soltar ${p.apelido || p.especie}?`)) return;
  try {
    await api.excluir(p.id);
    mostrarMensagem("Pokémon solto.");
    carregar();
  } catch (e) {
    mostrarMensagem(e.message, "erro");
  }
}

$("form-busca").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  try {
    const p = await api.pokedex($("especie").value);
    mostrarPrevia(p);
    if (!$("id").value) {
      $("especie-escolhida").value = p.especie;
      $("escolhido").textContent = `Pronto para capturar: ${p.especie}.`;
    }
    mostrarMensagem(`${p.especie} encontrado na Pokédex.`);
  } catch (e) {
    $("previa").hidden = true;
    mostrarMensagem(e.message, "erro");
  }
});

$("form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const dados = { apelido: $("apelido").value, nivel: $("nivel").value, notas: $("notas").value };
  try {
    const id = $("id").value;
    if (id) {
      await api.atualizar(id, dados);
      mostrarMensagem("Pokémon atualizado.");
    } else {
      if (!$("especie-escolhida").value) throw new Error("Busque um Pokémon na Pokédex antes de capturar.");
      await api.criar({ ...dados, especie: $("especie-escolhida").value });
      mostrarMensagem("Pokémon capturado!");
    }
    limparFormulario();
    carregar();
  } catch (e) {
    mostrarMensagem(e.message, "erro");
  }
});

$("btn-cancelar").addEventListener("click", limparFormulario);
$("busca").addEventListener("input", carregar);
carregar();
