const express = require("express");
const c = require("../controllers/pokemonController");

const router = express.Router();

router.get("/pokedex/:nome", c.pokedex); // consulta a API externa (não grava)
router.get("/pokemons", c.listar);
router.get("/pokemons/:id", c.buscar);
router.post("/pokemons", c.criar);
router.put("/pokemons/:id", c.atualizar);
router.delete("/pokemons/:id", c.excluir);

module.exports = router;
