// Regras da entidade e consultas SQL. Não conhece HTTP nem a API externa.
const db = require("../config/database");

const Pokemon = {
  validar(dados = {}) {
    const erros = [];
    const apelido = String(dados.apelido ?? "").trim();
    const notas = String(dados.notas ?? "").trim();
    const nivel = Number(dados.nivel ?? 1);

    if (apelido.length > 30) erros.push("Apelido deve ter no máximo 30 caracteres.");
    if (!Number.isInteger(nivel) || nivel < 1 || nivel > 100) erros.push("Nível deve ser um inteiro de 1 a 100.");
    if (notas.length > 300) erros.push("Notas devem ter no máximo 300 caracteres.");

    return { erros, valores: { apelido, nivel, notas } };
  },

  listar(busca = "") {
    return db
      .prepare("SELECT * FROM pokemons WHERE especie LIKE ? OR apelido LIKE ? ORDER BY id DESC")
      .all(`%${busca}%`, `%${busca}%`);
  },

  buscarPorId(id) {
    return db.prepare("SELECT * FROM pokemons WHERE id = ?").get(id);
  },

  criar(especie, { apelido, nivel, notas }) {
    const r = db
      .prepare(
        `INSERT INTO pokemons (especie_id, especie, tipos, imagem, hp, ataque, defesa, apelido, nivel, notas)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(especie.especie_id, especie.especie, especie.tipos, especie.imagem,
           especie.hp, especie.ataque, especie.defesa, apelido, nivel, notas);
    return this.buscarPorId(r.lastInsertRowid);
  },

  atualizar(id, { apelido, nivel, notas }) {
    const r = db
      .prepare("UPDATE pokemons SET apelido = ?, nivel = ?, notas = ? WHERE id = ?")
      .run(apelido, nivel, notas, id);
    return r.changes ? this.buscarPorId(id) : null;
  },

  excluir(id) {
    return db.prepare("DELETE FROM pokemons WHERE id = ?").run(id).changes > 0;
  },
};

module.exports = Pokemon;
