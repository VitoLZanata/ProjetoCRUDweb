// Decide status HTTP e formato da resposta. Orquestra o model e a API externa.
const Pokemon = require("../models/pokemonModel");
const pokeApi = require("../services/pokeApiService");

const idValido = (valor) => {
  const id = Number(valor);
  return Number.isInteger(id) && id > 0 ? id : null;
};

const responderErro = (res, e) => {
  if (e.status) return res.status(e.status).json({ erro: e.message });
  console.error(e);
  res.status(500).json({ erro: "Erro interno do servidor." });
};

exports.pokedex = async (req, res) => {
  try {
    res.status(200).json(await pokeApi.buscarPokemon(req.params.nome));
  } catch (e) {
    responderErro(res, e);
  }
};

exports.listar = (req, res) => {
  res.status(200).json(Pokemon.listar(req.query.busca));
};

exports.buscar = (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return res.status(400).json({ erro: "ID inválido." });
  const pokemon = Pokemon.buscarPorId(id);
  if (!pokemon) return res.status(404).json({ erro: "Pokémon não encontrado no time." });
  res.status(200).json(pokemon);
};

exports.criar = async (req, res) => {
  const { erros, valores } = Pokemon.validar(req.body);
  if (erros.length) return res.status(400).json({ erro: erros.join(" ") });
  try {
    const especie = await pokeApi.buscarPokemon(req.body?.especie);
    res.status(201).json(Pokemon.criar(especie, valores));
  } catch (e) {
    responderErro(res, e);
  }
};

exports.atualizar = (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return res.status(400).json({ erro: "ID inválido." });
  const { erros, valores } = Pokemon.validar(req.body);
  if (erros.length) return res.status(400).json({ erro: erros.join(" ") });
  const pokemon = Pokemon.atualizar(id, valores);
  if (!pokemon) return res.status(404).json({ erro: "Pokémon não encontrado no time." });
  res.status(200).json(pokemon);
};

exports.excluir = (req, res) => {
  const id = idValido(req.params.id);
  if (!id) return res.status(400).json({ erro: "ID inválido." });
  if (!Pokemon.excluir(id)) return res.status(404).json({ erro: "Pokémon não encontrado no time." });
  res.status(204).end();
};
