// Conexão com o SQLite e criação da tabela.
const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "..", "..", "database.sqlite"));

db.exec(`
  CREATE TABLE IF NOT EXISTS pokemons (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    especie_id INTEGER NOT NULL,
    especie    TEXT    NOT NULL,
    tipos      TEXT    NOT NULL DEFAULT '',
    imagem     TEXT    NOT NULL DEFAULT '',
    hp         INTEGER NOT NULL DEFAULT 0,
    ataque     INTEGER NOT NULL DEFAULT 0,
    defesa     INTEGER NOT NULL DEFAULT 0,
    apelido    TEXT    NOT NULL DEFAULT '',
    nivel      INTEGER NOT NULL DEFAULT 1,
    notas      TEXT    NOT NULL DEFAULT ''
  )
`);

module.exports = db;
