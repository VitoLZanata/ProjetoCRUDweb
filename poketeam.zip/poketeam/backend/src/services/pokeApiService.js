// Integração com a API externa (PokéAPI). Só este arquivo conhece a URL e o formato dela.
const BASE_URL = "https://pokeapi.co/api/v2/pokemon";

function erro(mensagem, status) {
  const e = new Error(mensagem);
  e.status = status;
  return e;
}

async function buscarPokemon(nomeOuId) {
  const termo = String(nomeOuId ?? "").trim().toLowerCase();
  if (!termo) throw erro("Informe o nome ou o número do Pokémon.", 400);

  let resposta;
  try {
    resposta = await fetch(`${BASE_URL}/${encodeURIComponent(termo)}`, { signal: AbortSignal.timeout(8000) });
  } catch {
    throw erro("Não foi possível acessar a PokéAPI. Tente novamente.", 502);
  }
  if (resposta.status === 404) throw erro(`Pokémon "${termo}" não encontrado na Pokédex.`, 404);
  if (!resposta.ok) throw erro("A PokéAPI respondeu com erro.", 502);

  const d = await resposta.json();
  const base = (nome) => d.stats.find((s) => s.stat.name === nome)?.base_stat ?? 0;
  return {
    especie_id: d.id,
    especie: d.name,
    tipos: d.types.map((t) => t.type.name).join(","),
    imagem: d.sprites?.other?.["official-artwork"]?.front_default || d.sprites?.front_default || "",
    hp: base("hp"),
    ataque: base("attack"),
    defesa: base("defense"),
  };
}

module.exports = { buscarPokemon };
